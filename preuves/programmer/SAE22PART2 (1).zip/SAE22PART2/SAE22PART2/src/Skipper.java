import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Skipper {

    public static void main(String[] args) {

        String url =
            "jdbc:postgresql://postgresql-std-7dc46fa421cd.apps.kappsul.su.univ-lorraine.fr:5432/imocadb";

        String login = "postgres";
        String password = "lDHReTjW0J";

        int ids = 0;

        try (Connection cnx =
                DriverManager.getConnection(url, login, password)) {

            PreparedStatement req = cnx.prepareStatement(
                "SELECT c.place, c.nombateau, co.edition " +
                "FROM classement c " +
                "JOIN course co ON c.idc = co.idc " +
                "WHERE c.ids = ?"
            );

            req.setInt(1, ids);

            ResultSet rs = req.executeQuery();

            Collection<LigneSkipper> resultat = new ArrayList<>();

            while (rs.next()) {

                LigneSkipper ligne = new LigneSkipper(
                    rs.getInt("place"),
                    rs.getString("nombateau"),
                    rs.getString("edition")
                );

                resultat.add(ligne);
            }

            Gson gson =
                new GsonBuilder().setPrettyPrinting().create();

            System.out.println(gson.toJson(resultat));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}