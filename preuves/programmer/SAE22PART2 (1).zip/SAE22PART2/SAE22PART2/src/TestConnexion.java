import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnexion {

    public static void main(String[] args) {

        String url = "jdbc:postgresql://postgresql-std-7dc46fa421cd.apps.kappsul.su.univ-lorraine.fr:5432/imocadb";
        String login = "postgres";
        String password = "lDHReTjW0J";

        try (Connection cnx = DriverManager.getConnection(url, login, password)) {
            System.out.println("Connexion réussie !");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}