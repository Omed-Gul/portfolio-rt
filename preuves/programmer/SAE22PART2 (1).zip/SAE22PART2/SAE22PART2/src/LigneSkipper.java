public class LigneSkipper {

    int place;
    String nombateau;
    String edition;

    public LigneSkipper(int place, String nombateau, String edition) {
        this.place = place;
        this.nombateau = nombateau;
        this.edition = edition;
    }
}