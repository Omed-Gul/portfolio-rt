import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Course {

    public static void main(String[] args) {

        String url =
            "jdbc:postgresql://postgresql-std-7dc46fa421cd.apps.kappsul.su.univ-lorraine.fr:5432/imocadb";

        String login = "postgres";
        String password = "lDHReTjW0J";

        int idc = 42;

        try (Connection cnx =
                DriverManager.getConnection(url, login, password)) {

            PreparedStatement req = cnx.prepareStatement(
                "SELECT c.place, c.nombateau, s.nom, s.prenom " +
                "FROM classement c " +
                "JOIN skipper s ON c.ids = s.ids " +
                "WHERE c.idc = ? " +
                "ORDER BY c.place"
            );

            req.setInt(1, idc);

            ResultSet rs = req.executeQuery();

            Collection<LigneCourse> resultat = new ArrayList<>();

            while (rs.next()) {

                LigneCourse ligne = new LigneCourse(
                    rs.getInt("place"),
                    rs.getString("nombateau"),
                    rs.getString("nom"),
                    rs.getString("prenom")
                );

                resultat.add(ligne);
            }

            Gson gson =
                new GsonBuilder().setPrettyPrinting().create();

            System.out.println(gson.toJson(resultat));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}