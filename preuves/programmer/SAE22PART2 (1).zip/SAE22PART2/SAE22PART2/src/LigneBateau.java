public class LigneBateau {

    int place;
    String nombateau;
    String nomskipper;
    String prenomskipper;
    String edition;

    public LigneBateau(int place,
                       String nombateau,
                       String nomskipper,
                       String prenomskipper,
                       String edition) {

        this.place = place;
        this.nombateau = nombateau;
        this.nomskipper = nomskipper;
        this.prenomskipper = prenomskipper;
        this.edition = edition;
    }
}
