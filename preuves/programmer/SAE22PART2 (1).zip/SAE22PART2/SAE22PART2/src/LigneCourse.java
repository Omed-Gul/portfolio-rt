public class LigneCourse {

    int place;
    String nombateau;
    String nomskipper;
    String prenomskipper;

    public LigneCourse(int place, String nombateau, String nomskipper, String prenomskipper) {
        this.place = place;
        this.nombateau = nombateau;
        this.nomskipper = nomskipper;
        this.prenomskipper = prenomskipper;
    }
}