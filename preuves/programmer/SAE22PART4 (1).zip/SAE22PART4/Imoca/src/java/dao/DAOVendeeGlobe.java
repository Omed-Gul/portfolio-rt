package dao;

import java.util.ArrayList;
import metier.DBClassement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hainry5
 */
public class DAOVendeeGlobe {

    public static ArrayList<DBClassement> lireClassement(Connection c, int idc) {
        ArrayList<DBClassement> liste = new ArrayList<>();
        try {
            PreparedStatement ps = c.prepareStatement("SELECT * FROM skipper NATURAL JOIN classement NATURAL JOIN course WHERE idc=? ORDER BY place ASC;");
            ps.setInt(1, idc);
            ResultSet r = ps.executeQuery();
            while (r.next()) {
                liste.add(new DBClassement(r.getInt("place"),
                        r.getString("prenom"),
                        r.getString("nom"),
                        r.getString("nombateau")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOVendeeGlobe.class.getName()).log(Level.SEVERE, null, ex);
        }
        return liste;
    }
}
