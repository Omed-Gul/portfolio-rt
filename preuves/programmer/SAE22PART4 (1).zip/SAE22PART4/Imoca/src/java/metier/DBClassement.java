package metier;

/**
 *
 * @author hainry5
 */
public class DBClassement {
    int rang;
    String prenom, nom, nombateau;

    public DBClassement(int rang, String prenom, String nom, String nombateau) {
        this.rang = rang;
        this.prenom = prenom;
        this.nom = nom;
        this.nombateau = nombateau;
    }
}
