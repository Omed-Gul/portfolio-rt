package metier;

/**
 *
 * @author hainry5
 */
public class DBSkipper {
    String prenom, nom;
    int jour, mois, annee;
    String nationalite;

    public DBSkipper(String prenom, String nom, int jour, int mois, int annee, String nationalite) {
        this.prenom = prenom;
        this.nom = nom;
        this.jour = jour;
        this.mois = mois;
        this.annee = annee;
        this.nationalite = nationalite;
    }
}
