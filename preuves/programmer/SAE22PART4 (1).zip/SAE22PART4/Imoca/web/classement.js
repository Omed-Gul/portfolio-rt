fetch("http://localhost:8080/SAE22PART3/Course")
    .then(r => r.json())
    .then(afficherClassement);

function afficherClassement(donnees) {

    let tbody = document.getElementById("classement");

    for (let ligne of donnees) {

        let tr = document.createElement("tr");

        tr.innerHTML =
                "<td>" + ligne.place + "</td>" +
                "<td>" + ligne.nombateau + "</td>" +
                "<td>" + ligne.prenomskipper + " " + ligne.nomskipper + "</td>";

        tbody.appendChild(tr);
    }
}