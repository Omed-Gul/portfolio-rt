fetch("http://localhost:8080/SAE22PART3/Bateau")
    .then(r => r.json())
    .then(afficher);

function afficher(donnees) {

    let tbody = document.getElementById("palmares");

    for (let ligne of donnees) {

        let tr = document.createElement("tr");

        tr.innerHTML =
                "<td>" + ligne.place + "</td>" +
                "<td>" + ligne.nombateau + "</td>" +
                "<td>" + ligne.prenomskipper + " " + ligne.nomskipper + "</td>" +
                "<td>" + ligne.edition + "</td>";

        tbody.appendChild(tr);
    }
}