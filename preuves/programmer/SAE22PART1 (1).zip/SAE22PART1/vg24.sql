INSERT INTO Course VALUES (45, '2024-2025');

INSERT INTO Bateau VALUES (94, 'Verdier', 2023);

INSERT INTO Skipper VALUES (
    259,
    'Mettraux',
    'Justine',
    528768000,
    'CH'
);

INSERT INTO Classement VALUES (
    94,
    4,
    45,
    1,
    'Macif Santé Prévoyance'
);

INSERT INTO Classement VALUES (
    7,
    259,
    45,
    8,
    'Teamwork - Team SNEF'
);
