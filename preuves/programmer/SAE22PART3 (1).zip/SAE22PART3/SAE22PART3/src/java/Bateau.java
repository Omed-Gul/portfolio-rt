import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

public class Bateau extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Collection<LigneBateau> palmares = new ArrayList<>();

        try {
            InitialContext cxt = new InitialContext();
            DataSource ds = (DataSource) cxt.lookup("java:/comp/env/jdbc/postgres");

            try (Connection cnx = ds.getConnection()) {

                int idb = 12;

                PreparedStatement req = cnx.prepareStatement(
                    "SELECT cl.place, cl.nombateau, s.nom, s.prenom, co.edition " +
                    "FROM classement cl " +
                    "JOIN skipper s ON cl.ids = s.ids " +
                    "JOIN course co ON cl.idc = co.idc " +
                    "WHERE cl.idb = ?"
                );

                req.setInt(1, idb);

                ResultSet rs = req.executeQuery();

                while (rs.next()) {
                    palmares.add(
                        new LigneBateau(
                            rs.getInt("place"),
                            rs.getString("nombateau"),
                            rs.getString("nom"),
                            rs.getString("prenom"),
                            rs.getString("edition")
                        )
                    );
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String res = gson.toJson(palmares);

        response.setContentType("application/json;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println(res);
        }
    }
}