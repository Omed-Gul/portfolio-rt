import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

public class Course extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Collection<LigneCourse> classement = new ArrayList<>();

        try {
            InitialContext cxt = new InitialContext();
            DataSource ds = (DataSource) cxt.lookup("java:/comp/env/jdbc/postgres");

            try (Connection cnx = ds.getConnection()) {

                PreparedStatement req = cnx.prepareStatement(
                        "SELECT c.place, c.nombateau, s.nom, s.prenom "
                        + "FROM classement c "
                        + "JOIN skipper s ON c.ids = s.ids "
                        + "WHERE c.idc = ? "
                        + "ORDER BY c.place"
                );

                req.setInt(1, 42);

                ResultSet rs = req.executeQuery();

                while (rs.next()) {
                    classement.add(
                            new LigneCourse(
                                    rs.getInt("place"),
                                    rs.getString("nombateau"),
                                    rs.getString("nom"),
                                    rs.getString("prenom")
                            )
                    );
                }
            }

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String res = gson.toJson(classement);

            response.setContentType("application/json;charset=UTF-8");

            try (PrintWriter out = response.getWriter()) {
                out.println(res);
            }

        } catch (Exception e) {
            response.getWriter().println(e.getMessage());
        }
    }
}